<?php 
class Zend_View_Helper_NavigationMenu 
{
	
	public function navigationMenu() {
		return 'navigationMenu test view';	
	}
	
	
}

?>
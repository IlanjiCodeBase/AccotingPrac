<?php 
require_once "Account/Uploader.php";
class Transaction_JournalController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->settings    = new Settings();
		$this->accountData = new Account_Data();
		if(Zend_Session::namespaceIsset('sess_login')) {
			$logSession = new Zend_Session_Namespace('sess_login');	
			if(isset($logSession) && !empty($logSession->id) && !empty($logSession->cid)) {
				if($logSession->type==0 && !isset($logSession->proxy_type)) {
					$this->_redirect('developer');
				} 
			} else {
				$this->_redirect('index');
			}
		} else {
			$this->_redirect('index');
		}	
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$sort   = $this->_getParam('sort');
			if(isset($sort) && !empty($sort) && ($sort==1 || $sort==2)) {
				$sort   = $this->_getParam('sort');
			} else {
				$sort = '';
			}

			$this->view->sort = $sort;
			if(Zend_Session::namespaceIsset('insert_success_journal')) {
				$this->view->success = 'Jounral Entries Added successfully';
				Zend_Session::namespaceUnset('insert_success_journal');
			}
			if(Zend_Session::namespaceIsset('delete_success_journal')) {
				$this->view->success = 'Journal Entry deleted successfully';
				Zend_Session::namespaceUnset('delete_success_journal');
			}
			if(Zend_Session::namespaceIsset('delete_error_journal')) {
				$this->view->error = 'Journal Entry cannot be deleted';
				Zend_Session::namespaceUnset('delete_error_journal');
			}
			if(Zend_Session::namespaceIsset('verify_success_journal_transaction')) {
				$this->view->success = 'Journal Entry verified successfully';
				Zend_Session::namespaceUnset('verify_success_journal_transaction');
			}
			if(Zend_Session::namespaceIsset('unverify_success_journal_transaction')) {
				$this->view->success = 'Journal Entry unverified successfully';
				Zend_Session::namespaceUnset('unverify_success_journal_transaction');
			}
			if(Zend_Session::namespaceIsset('sess_draft_journal_insert')) {
				$this->view->success = 'Journal Entry saved as draft';
				Zend_Session::namespaceUnset('sess_draft_journal_insert');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeJournalTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$sessSuccess = new Zend_Session_Namespace('verify_success_journal_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$sessSuccess = new Zend_Session_Namespace('unverify_success_journal_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/journal');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteJournalTransaction($delid);
				if($deleteStatus && $deleteStatus==1) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_journal');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/journal');
				} elseif ($deleteStatus && $deleteStatus==3) {
					$sessError = new Zend_Session_Namespace('delete_error_journal');
					$sessError->status = 1;
					$this->_redirect('transaction/journal');
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->taxCode    	=  $this->transaction->getTax(1);
			$this->view->result 		=  $this->transaction->getJournalTransaction($id='',$sort);
		}
	}

	public function addAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->fileuploadpath    =  $this->uploadPath.$cid."/journal/";
			$this->view->nextId 	 =  $this->transaction->getNextJournalTransaction();
			if($this->_request->isPost()) {
				$postArray  = $this->getRequest()->getPost();

			/*	$adapter    =  new Zend_File_Transfer_Adapter_Http();
				$fileInfo 	=  $adapter->getFileInfo('file'); 
				if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
					$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
					        ->addValidator('Size',false,array('max'=>2024000),'file')
							->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
					$adapter->setDestination("..".$this->fileuploadpath,'file');
					$fileInfo 	         	  =   $adapter->getFileInfo('file');
					$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
					$postArray['extension']   =   $fileArray['1'];
					$renameFile 		  	  =   trim($this->view->nextId."_".rand(10,10000)."_".$this->view->nextId.".".$fileArray['1']);
					$postArray['attach_file'] =   $renameFile;
					$adapter->addFilter('Rename',"..".$this->fileuploadpath.$renameFile);
						if ($adapter->isValid('file') && $adapter->receive('file')) {
							$postArray['attach_file'] =   $renameFile;
						} else {
							$postArray['attach_file'] =   '';
						}
				} else {
					$postArray['attach_file'] =   '';
				}*/
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$journalTransaction = $this->transaction->insertJournalTransaction($postArray,$cid,2);
				} else if(isset($postArray['approve_journal']) && !empty($postArray['approve_journal'])) {
					$postArray['approval_for'] = $logSession->id;
					$journalTransaction = $this->transaction->insertJournalTransaction($postArray,$cid,1);
				} 
				if($journalTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_journal');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/journal/');
				} else {
						$this->view->error = 'journal Entries cannot be added. Kindly try again later';
				}
			}
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->payAccount		=  $this->transaction->getAllAccount();
		}
	}


	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->fileuploadpath    =  $this->uploadPath.$cid."/journal/";
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/journal');
			} else {
				$this->view->journal  =  $this->transaction->getJournalTransaction($id);
				if(!$this->view->journal) {
					$this->_redirect('transaction/journal');
				} else {
					$this->view->journalEntryList  =  $this->transaction->getJournalEntryList($id);
					if(!$this->view->journalEntryList) {
						$this->_redirect('transaction/journal');
					} 
				}
			}
			$this->view->approveUser	=  $this->settings->getApproveUsers();
			$this->view->payAccount		=  $this->transaction->getAllAccount();
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_journal')) {
				$this->view->success = 'Journal Entry Updated successfully';
				Zend_Session::namespaceUnset('update_success_journal');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->fileuploadpath    =  $this->uploadPath.$cid."/journal/";
			$id = base64_decode($this->_getParam('id'));
			$this->view->journ_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/journal');
			} else {
				$this->view->journal  =  $this->transaction->getJournalTransaction($id);
				if(!$this->view->journal) {
					$this->_redirect('transaction/journal');
				} else {
					$this->view->journalEntryList  =  $this->transaction->getJournalEntryList($id);
					if(!$this->view->journalEntryList) {
						$this->_redirect('transaction/journal');
					} 
				}
			}
			//print_r($this->view->journal);
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();

				/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
				$fileInfo 	=  $adapter->getFileInfo('file'); 
				if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
					$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
					        ->addValidator('Size',false,array('max'=>2024000),'file')
							->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
					$adapter->setDestination("..".$this->view->fileuploadpath,'file');
					$fileInfo 	         	  =   $adapter->getFileInfo('file');
					$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
					$postArray['extension']   =   $fileArray['1'];
					$renameFile 		  	  =   trim($id."_".rand(10,10000)."_".$id.".".$fileArray['1']);
					$postArray['attach_file'] =   $renameFile;
					$adapter->addFilter('Rename',"..".$this->view->fileuploadpath.$renameFile);
						if ($adapter->isValid('file') && $adapter->receive('file')) {
							//unlink($this->view->fileuploadpath.$postArray['attachment']);
							$postArray['attach_file'] =   $renameFile;
						} else {
							$postArray['attach_file'] =  $postArray['attachment'];
						}
				} else {
					$postArray['attach_file'] =  $postArray['attachment'];
				}
*/

				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$journalTransaction = $this->transaction->updateJournalTransaction($postArray,$id,2);
				} else if(isset($postArray['approve_journal']) && !empty($postArray['approve_journal'])) {
					$postArray['approval_for'] = $logSession->id;
					$journalTransaction = $this->transaction->updateJournalTransaction($postArray,$id,1);
				} 

				
				if($journalTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_journal');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/journal/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Journal Entries cannot be updated. Kindly try again later';
				}
			}
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->payAccount		=  $this->transaction->getAllAccount();
		}
	}

public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->fileuploadpath    =  $this->uploadPath.$cid."/journal/";
			$this->view->nextId 	 	   =  $this->transaction->getNextJournalTransaction();
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/journal');
			} else {
				$this->view->journal  =  $this->transaction->getJournalTransaction($id);
				if(!$this->view->journal) {
					$this->_redirect('transaction/journal');
				} else {
					$this->view->journalEntryList  =  $this->transaction->getJournalEntryList($id);
					if(!$this->view->journalEntryList) {
						$this->_redirect('transaction/journal');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  = $this->getRequest()->getPost();
			/*	$adapter    =  new Zend_File_Transfer_Adapter_Http();
				$fileInfo 	=  $adapter->getFileInfo('file'); 
				if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
					$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
					        ->addValidator('Size',false,array('max'=>2024000),'file')
							->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
					$adapter->setDestination("..".$this->view->fileuploadpath,'file');
					$fileInfo 	         	  =   $adapter->getFileInfo('file');
					$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
					$postArray['extension']   =   $fileArray['1'];
					$renameFile 		  	  =   trim($this->view->nextId."_".rand(10,10000)."_".$this->view->nextId.".".$fileArray['1']);
					$postArray['attach_file'] =   $renameFile;
					$adapter->addFilter('Rename',"..".$this->view->fileuploadpath.$renameFile);
						if ($adapter->isValid('file') && $adapter->receive('file')) {
							$postArray['attach_file'] =   $renameFile;
						} else {
							$postArray['attach_file'] =  $postArray['attachment'];
						}
				} else {
					$postArray['attach_file'] =  $postArray['attachment'];
				}*/
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$journalTransaction = $this->transaction->insertJournalTransaction($postArray,$cid,2);
				} else if(isset($postArray['approve_journal']) && !empty($postArray['approve_journal'])) {
					$postArray['approval_for'] = $logSession->id;
					$journalTransaction = $this->transaction->insertJournalTransaction($postArray,$cid,1);
				} 
				if($journalTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_journal');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/journal/');
				} else {
						$this->view->error = 'journal Entries cannot be added. Kindly try again later';
				}
			}
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->payAccount		=  $this->transaction->getAllAccount();
		}
	}

	public function ajaxRefreshAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
			if($ajaxVal['action']=='accountRefresh') {
					$this->payAccount		=  $this->transaction->getAllAccount();
					if($this->payAccount) {
						$jsonEncode = json_encode($this->payAccount);
						echo $jsonEncode;
					}
				}
			}
		}
	}

	public function ajaxUploadAction() {

		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
		$this->view->filepath    =  "..".$this->uploadPath.$cid."/journal/";
		$action = $this->_getParam('operation');

		if($action=='add') {
				$this->view->nextId 	 =  $this->transaction->getNextJournalTransaction();

				$uploader = new FileUpload('uploadfile');   
				$uploader->allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'doc');
				$uploader->sizeLimit = 10485760;
				$extension = $uploader->getExtension();
				$newfilename  = $this->view->nextId."_".rand(10,10000)."_journal.".$extension;
				$uploader->newFileName = $newfilename;
				$result = $uploader->handleUpload($this->view->filepath);

				if (!$result) {

				  echo json_encode(array(

				          'status' => "failure",

				          'file' => $uploader->getErrorMsg()

				       ));    

				} else {

				    echo json_encode(array ( 'data' => array(

				            'status' => "success",

				            'file' => $uploader->getFileName()

				         )));

				}
		}  else if($action=='edit') {

				$fileid = $this->_getParam('id');
				$uploader = new FileUpload('uploadfile');   
				$uploader->allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'doc');
				$uploader->sizeLimit = 10485760;
				$extension = $uploader->getExtension();
				$newfilename  = $fileid."_".rand(10,10000)."_journal.".$extension;
				$uploader->newFileName = $newfilename;
				$result = $uploader->handleUpload($this->view->filepath);

				if (!$result) {

				  echo json_encode(array(

				          'status' => "failure",

				          'file' => $uploader->getErrorMsg()

				       ));    

				} else {

				    echo json_encode(array ( 'data' => array(

				            'status' => "success",

				            'file' => $uploader->getFileName()

				         )));

				}
		} 
	}

	public function ajaxRemoveAction() {

		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
		$this->view->filepath    =  "..".$this->uploadPath.$cid."/journal/";
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='fileRemove') {
					$unlinkFile = unlink($this->view->filepath.$ajaxVal['id']);
					if($unlinkFile) {
						echo "success";
					} else {
						echo "failure";
					}
				}
			}
		}

	}


	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
		$this->fileuploadpath    =  $this->uploadPath.$cid."/journal/";
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();

				if($ajaxVal['action']=='save_draft_journal') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));

					/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
					$fileInfo 	=  $adapter->getFileInfo('file'); 
					if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
						$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
						        ->addValidator('Size',false,array('max'=>2024000),'file')
								->addValidator('Extension',false,'pdf,jpg','file');
						$adapter->setDestination("..".$this->fileuploadpath,'file');
						$fileInfo 	         	  =   $adapter->getFileInfo('file');
						$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
						$ajaxVal['extension']     =   $fileArray['1'];
						$renameFile 		  	  =   trim($cid."_".rand(10,10000)."_".$cid.".".$fileArray['1']);
						$postArray['attach_file'] =   $renameFile;
						$adapter->addFilter('Rename',"..".$this->fileuploadpath.$renameFile);
							if ($adapter->isValid('file') && $adapter->receive('file')) {
								$ajaxVal['attach_file'] =   $renameFile;
							} else {
								$ajaxVal['attach_file'] =   '';
							}
					} else {
						$ajaxVal['attach_file'] =   '';
					}*/
					$ajaxVal['attach_file'] =   '';
					$journalTransaction = $this->transaction->insertJournalTransaction($ajaxVal,$cid,3);
					if($journalTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_journal_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} else if($ajaxVal['action']=='update_draft_journal') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));

					/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
					$fileInfo 	=  $adapter->getFileInfo('file'); 
					if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
						$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
						        ->addValidator('Size',false,array('max'=>2024000),'file')
								->addValidator('Extension',false,'pdf,jpg','file');
						$adapter->setDestination("..".$this->view->fileuploadpath,'file');
						$fileInfo 	         	  =   $adapter->getFileInfo('file');
						$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
						$ajaxVal['extension']     =   $fileArray['1'];
						$renameFile 		  	  =   trim($cid."_".rand(10,10000)."_".$cid.".".$fileArray['1']);
						$postArray['attach_file'] =   $renameFile;
						$adapter->addFilter('Rename',"..".$this->view->fileuploadpath.$renameFile);
							if ($adapter->isValid('file') && $adapter->receive('file')) {
								//unlink($this->view->fileuploadpath.$postArray['attachment']);
								$ajaxVal['attach_file'] =   $renameFile;
							} else {
								$ajaxVal['attach_file'] =  $ajaxVal['attachment'];
							}
					} else {
						$ajaxVal['attach_file'] =  $ajaxVal['attachment'];
					}*/
					$journalTransaction = $this->transaction->updateJournalTransaction($ajaxVal,$ajaxVal['journal_id'],3);
					if($journalTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_journal_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} 
			}
		} 
	}

		
}

?>
<?php 
class Transaction_CreditController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->settings    = new Settings();
		$this->accountData = new Account_Data();
		if(Zend_Session::namespaceIsset('sess_login')) {
			$logSession = new Zend_Session_Namespace('sess_login');	
			if($logSession->type==0 && !isset($logSession->companySet)) {
				$this->_redirect('developer');
			}
		} else {
			$this->_redirect('index');
		}		
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			if(Zend_Session::namespaceIsset('insert_success_credit')) {
				$this->view->success = 'Credit Note Added successfully';
				Zend_Session::namespaceUnset('insert_success_credit');
			}
			if(Zend_Session::namespaceIsset('delete_success_credit_transaction')) {
				$this->view->success = 'Credit Note deleted successfully';
				Zend_Session::namespaceUnset('delete_success_credit_transaction');
			}
			if(Zend_Session::namespaceIsset('mark_success_credit_transaction')) {
				$this->view->success = 'Credit Note marked successfully';
				Zend_Session::namespaceUnset('mark_success_credit_transaction');
			}
			if(Zend_Session::namespaceIsset('verify_success_credit_transaction')) {
				$this->view->success = 'Transaction verified successfully';
				Zend_Session::namespaceUnset('verify_success_credit_transaction');
			}
			if(Zend_Session::namespaceIsset('unverify_success_credit_transaction')) {
				$this->view->success = 'Transaction unverified successfully';
				Zend_Session::namespaceUnset('unverify_success_credit_transaction');
			}
			$sentid = base64_decode($this->_getParam('sentid'));
			if(isset($sentid) && !empty($sentid)) {
				$markStatus = $this->transaction->markCreditTransaction($sentid,1);
				if($markStatus) {
					$sessSuccess = new Zend_Session_Namespace('mark_success_credit_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/credit');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteCreditTransaction($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_credit_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/credit');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeCreditTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$sessSuccess = new Zend_Session_Namespace('verify_success_credit_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$sessSuccess = new Zend_Session_Namespace('unverify_success_credit_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/credit');
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->result 		=  $this->transaction->getCreditTransaction();
		}
	}

	public function addAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,2);
				} else if(isset($postArray['approve_invoice']) && !empty($postArray['approve_credit'])) {
					$postArray['approval_for'] = $logSession->id;
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,1);
				} 
				if($creditTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_credit');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/credit/');
				} else {
						$this->view->error = 'Credit note cannot be added. Kindly try again later';
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_credit')) {
				$this->view->success = 'Credit Note Added successfully';
				Zend_Session::namespaceUnset('insert_success_credit');
			}
			
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->creditNo    	=  $this->transaction->generateCreditNo();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->invoice 		=  $this->transaction->getInvoiceCreditTransaction();
			$this->view->creditSet 		=  1;
		}
	}

	public function copyInvoiceAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = $this->_getParam('id');
			$this->view->inv_id = $this->_getParam('id');
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/credit');
			} else {
				$this->view->invoice  =  $this->transaction->getInvoiceTransaction($id);
				if(!$this->view->invoice) {
					$this->_redirect('transaction/credit');
				} else {
					$this->view->invoiceProductList  =  $this->transaction->getInvoiceProductList($id);
					if(!$this->view->invoiceProductList) {
						$this->_redirect('transaction/credit');
					} 
				}
			}	
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,2);
				} else if(isset($postArray['approve_credit']) && !empty($postArray['approve_credit'])) {
					$postArray['approval_for'] = $logSession->id;
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,1);
				} 
				if($creditTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_credit');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/credit/');
				} else {
						$this->view->error = 'Credit note cannot be added. Kindly try again later';
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_credit')) {
				$this->view->success = 'Credit Note Added successfully';
				Zend_Session::namespaceUnset('insert_success_credit');
			}
			
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->creditNo    	=  $this->transaction->generateCreditNo();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->invoices 		=  $this->transaction->getInvoiceCreditTransaction();
			$this->view->creditSet 		=  1;
		}
	}

	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/credit');
			} else {
				$this->view->credit  =  $this->transaction->getCreditTransaction($id);
				if(!$this->view->credit) {
					$this->_redirect('transaction/credit');
				} else {
					$this->view->creditProductList  =  $this->transaction->getCreditProductList($id);
					if(!$this->view->creditProductList) {
						$this->_redirect('transaction/invoice');
					} 
				}
			}	
			
			$getAccountArray            =  $this->accountData->getData(array('currencies'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_credit')) {
				$this->view->success = 'Credit Note Updated successfully';
				Zend_Session::namespaceUnset('update_success_credit');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/credit');
			} else {
				$this->view->credit  =  $this->transaction->getCreditTransaction($id);
				if(!$this->view->credit) {
					$this->_redirect('transaction/credit');
				} else {
					$this->view->creditProductList  =  $this->transaction->getCreditProductList($id);
					if(!$this->view->creditProductList) {
						$this->_redirect('transaction/credit');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$creditTransaction = $this->transaction->updateCreditTransaction($postArray,$id,2);
				} else if(isset($postArray['approve_credit']) && !empty($postArray['approve_credit'])) {
					$postArray['approval_for'] = $logSession->id;
					$creditTransaction = $this->transaction->updateCreditTransaction($postArray,$id,1);
				} 
				if($creditTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_credit');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/credit/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Credit Note cannot be updated. Kindly try again later';
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
		}
	}

	public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/credit');
			} else {
				$this->view->credit  =  $this->transaction->getCreditTransaction($id);
				if(!$this->view->credit) {
					$this->_redirect('transaction/credit');
				} else {
					$this->view->creditProductList  =  $this->transaction->getCreditProductList($id);
					if(!$this->view->creditProductList) {
						$this->_redirect('transaction/credit');
					} 
				}
			}	
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,2);
				} else if(isset($postArray['approve_credit']) && !empty($postArray['approve_credit'])) {
					$postArray['approval_for'] = $logSession->id;
					$creditTransaction = $this->transaction->insertCreditTransaction($postArray,$cid,1);
				} 
				if($creditTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_credit');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/credit');
				} else {
						$this->view->error = 'Credit Note cannot be added. Kindly try again later';
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->creditNo    	=  $this->transaction->generateCreditNo();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
		}
	}

	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		$cid = $logSession->cid;
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='save_draft_credit') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));
					if(isset($ajaxVal['customer']) && !empty($ajaxVal['customer'])) {
						$ajaxVal['customer'] = trim($ajaxVal['customer']);
					} else {
						$ajaxVal['customer'] = NULL;
					}
					if(isset($ajaxVal['invoice']) && !empty($ajaxVal['invoice'])) {
						$ajaxVal['invoice'] = trim($ajaxVal['invoice']);
					} else {
						$ajaxVal['invoice'] = NULL;
					}
					$creditTransaction = $this->transaction->insertCreditTransaction($ajaxVal,$cid,3);
					if($creditTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_credit_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} else if($ajaxVal['action']=='update_draft_credit') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));
					if(isset($ajaxVal['customer']) && !empty($ajaxVal['customer'])) {
						$ajaxVal['customer'] = trim($ajaxVal['customer']);
					} else {
						$ajaxVal['customer'] = NULL;
					}
					$creditTransaction = $this->transaction->updateCreditTransaction($ajaxVal,$ajaxVal['credit_id'],3);
					if($creditTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_credit_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} 
			}
		} 
	}

		
}

?>
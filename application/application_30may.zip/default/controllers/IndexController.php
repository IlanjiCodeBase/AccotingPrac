<?php 
class IndexController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->account 	   = new Account();
		$this->transaction = new Transaction();
		$this->settings    = new Settings();
		$this->approval    = new Approval();
		$this->accountData = new Account_Data();	
		$this->uploadPath  = Zend_Registry::get('uploadpath');

		if(Zend_Session::namespaceIsset('sess_login')) {

			$logSession = new Zend_Session_Namespace('sess_login');

			if(isset($logSession->proxy_id) && !empty($logSession->proxy_id)) {
				$id = $logSession->proxy_id;
			} else {
				$id = $logSession->id;
			}

			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}

			$notify = array();
			$countMessage = 0; 
			$countUnseenMessage = 0; 
			
			$this->view->defaultTheme = $this->account->getDefaultTheme();
			$this->view->companyLogo  = $this->account->getCompanyLogo();
			$this->view->logopath     = $this->uploadPath.$cid."/";
			$this->notifications = $this->approval->getNotificationMessage($cid,$id);
			if(isset($this->notifications) && !empty($this->notifications)) {
				foreach ($this->notifications as $notification) {
					$users 			= explode(",", $notification['users']);
					$seen_users 	= explode(",", $notification['seen_users']);
					if(in_array($id,$users) || $notification['users']=='all') {
						if(in_array($id, $seen_users)) {
							$notify[$notification['id']]['seen'] = 1;
						} else {
							$notify[$notification['id']]['seen'] = 2;
							$countUnseenMessage++;
						}
						$countMessage++; 
						$notify[$notification['id']]['subject'] = $notification['subject'];
						$notify[$notification['id']]['message'] = $notification['message'];
						$notify[$notification['id']]['date']    = $notification['date_created'];
					}
				}
			}

			$this->view->notifyMessage  	   = $countMessage;
			$this->view->notifyUnseenMessage   = $countUnseenMessage;
			$this->view->notifyHeaderMessage   = $notify;
		}
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(Zend_Session::namespaceIsset('sess_login')) {
			$this->_redirect('index/dashboard');
		} else {
		if($this->_request->isPost()) {
			$postArray  = 	$this->getRequest()->getPost();
			$result     =   $this->account->userAuth($postArray);
			if($result) {
			//	echo '<pre>'; print_r($result); echo '</pre>'; die();
				$logSession = new Zend_Session_Namespace('sess_login');
				//$logSession->setExpirationSeconds(10); 
				$logSession->id		  = $result[0]['id'];
				$logSession->type	  = $result[0]['account_type'];
				$logSession->name 	  = $result[0]['company_name'];
				$logSession->cid  	  = $result[0]['cid'];
				$logSession->currency = $result[0]['currency'];
				$logSession->status   = $result[0]['status'];
				$logSession->username = $postArray['username'];
				$logSession->server   = $result[0]['server_address'];
				//$this->_redirect('index/dashboard');
				if($result[0]['server_address'] == 'main_default') {
					$this->_redirect('developer');
				} else {
					if($result[0]['server_address'] == 'default') {
						$remoteSession 	= new Zend_Session_Namespace('sess_remote_database');
						$remoteSession->hostName = "localhost";
						$remoteSession->userName = "root";
						$remoteSession->password = "";
						$remoteSession->dataBase = $result[0]['database_name'];
					} else {
						$remoteSession = new Zend_Session_Namespace('sess_remote_database');
						$remoteSession->hostName = $result[0]['server_address'];
						$remoteSession->userName = $result[0]['server_user'];
						$remoteSession->password = $result[0]['server_pass'];
						$remoteSession->dataBase = $result[0]['database_name'];
					}
					if($logSession->type!=0) {
						$auditLog	  = $this->settings->insertAuditLogin(9,12,'Logged In',$logSession->type);
					}					
					if($result[0]['account_type']==0 || $result[0]['account_type'] == 1) {
						$this->_redirect('developer');
					}  else if($result[0]['account_type'] == 2) { 
						$logSession->companySet = 1;
						if($logSession->status==2) {
							$this->_redirect('settings/company');
						} else {
							$this->_redirect('settings');
						}
					} else {
                        $this->_redirect('index/dashboard');
                     }
					//echo '<pre>'; print_r($result); echo '</pre>';
				}
				/* $remoteSession->hostName = "103.14.121.168";
				$remoteSession->userName = "ummgroup";
				$remoteSession->password = "accelerated2020";
				$remoteSession->dataBase = "ummgroup_money_exchange"; */
			} else {
			 	$this->view->error = 'Invalid Login Details';
			}
		}
	  }
	}

	public function dashboardAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			$this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');

			if(isset($logSession->proxy_id) && !empty($logSession->proxy_id)) {
				$id = $logSession->proxy_id;
			} else {
				$id = $logSession->id;
			}

			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}

			$notify = array();


			if($logSession->status==2) {
				$this->_redirect('settings/company');
			}

			if($logSession->type==2 || $logSession->type==3 || $logSession->proxy_type==2 || $logSession->proxy_type==3) {
				$pendingIncome  = $this->transaction->pendingIncomeTransactions($id);
				$pendingExpense = $this->transaction->pendingExpenseTransactions($id);
				$pendingInvoice = $this->transaction->pendingInvoiceTransactions($id);
				$pendingCredit  = $this->transaction->pendingCreditTransactions($id);
				$pendingjournal = $this->transaction->pendingJournalTransactions($id);
				$this->view->totalCount = $pendingIncome+$pendingExpense+$pendingInvoice+$pendingCredit+$pendingjournal;
			}

			$this->notifications = $this->approval->getNotificationMessage($cid,$id);
			if(isset($this->notifications) && !empty($this->notifications)) {
				foreach ($this->notifications as $notification) {
					$users 			= explode(",", $notification['users']);
					$seen_users 	= explode(",", $notification['seen_users']);
					if((in_array($id,$users) && !in_array($id, $seen_users)) || ($notification['users']=='all' && !in_array($id, $seen_users))) {
						$notify[$notification['id']]['subject'] = $notification['subject'];
						$notify[$notification['id']]['message'] = $notification['message'];
						$notify[$notification['id']]['date']    = $notification['date_created'];
					}
				}
			}

			$this->view->notifyMessages = $notify;
			
		}
	}

	public function registrationAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			$this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if($logSession->type!=0) {
				$this->_redirect('index');
			}
			$getAccountArray              =  $this->accountData->getData(array('country'));
			$this->view->countries        =  $getAccountArray['country'];
			if(Zend_Session::namespaceIsset('insert_account_success')) {
				$sessSuccess = new Zend_Session_Namespace('insert_account_success');
				$this->view->success = 'Account Created successfully';
				//$this->view->success = 'Account Created successfully. Kindly <a href="'.$this->view->sitePath."developer/configure-database/company/".base64_encode($sessSuccess->companyId).'">click here</a> to assign database and load accounts for the company.';
				Zend_Session::namespaceUnset('insert_account_success');
			}
			if(Zend_Session::namespaceIsset('insert_account_success_nodb')) {
				$sessSuccess = new Zend_Session_Namespace('insert_account_success_nodb');
				$this->view->success = 'Account Created successfully but problem in creating database and configuring it. Kindly configure database manually';
				Zend_Session::namespaceUnset('insert_account_success_nodb');
			}
			if($this->_request->isPost()) {
				$postArray  = 	$this->getRequest()->getPost(); 
				$postArray['account_type'] = 2;
				$this->view->username 	= $postArray['username'];
				$this->view->company 	= $postArray['company'];
				$this->view->cuen 		= $postArray['cuen'];
				$this->view->gst 		= $postArray['gst'];
				$this->view->phone 		= $postArray['phone'];
				$this->view->block_no 	= $postArray['block_no'];
				$this->view->street_name= $postArray['street_name'];
				$this->view->level   	= $postArray['level'];
				$this->view->unit_no    = $postArray['unit_no'];
				$this->view->city   	= $postArray['city'];
				$this->view->zip_code   = $postArray['zip_code'];
				$this->view->region   	= $postArray['region'];
				$this->view->country    = $postArray['country'];
				$this->view->start_date	= $postArray['start_date'];
				$this->view->end_date   = $postArray['end_date'];
				$start_date	 = date('d-m-Y',strtotime($postArray['start_date']));
				$finish_date = strtotime(date("d-m-Y", strtotime($postArray['end_date'])) . " +1 year");;
				$end_date    = date('d-m-Y',$finish_date);
				$start = strtotime($start_date);
                $end   = strtotime($end_date);
                $days_between = ceil(abs($end - $start) / 86400); 
                if($days_between=='364' || $days_between=='366') {
					$checkUsername			= $this->account->checkLogin($postArray['username']);
						if(!$checkUsername) {
						$result     			= $this->account->insertCompany($postArray);
						if($result) {
							$insertLogin = $this->account->insertLogin($postArray,$result);
							 if($insertLogin) {
							 	//mkdir("../".$this->receiptPath.$result);
							 	//mkdir("../".$this->uploadPath."journal/".$result);
							 	mkdir("../".$this->uploadPath.$result);
							 	mkdir("../".$this->uploadPath.$result."/receipts");
							 	mkdir("../".$this->uploadPath.$result."/journal");
							 	mkdir("../".$this->uploadPath.$result."/imports");
							 	mkdir("../".$this->uploadPath.$result."/sql");
							 	$file = "..".$this->uploadPath."/accounts.json";
								$newfile = "..".$this->uploadPath.$result."/accounts.json";
								copy($file, $newfile);
							 	//mkdir("../".$result."/accounts");
							 	$database_name = "ummtech1_accounting_".$result;
							 	$sql_filename = 'accounting.sql';
								$sql_contents = file_get_contents("../".$this->uploadPath.$sql_filename);
								$sql_contents = explode("@@", $sql_contents);
								if(!empty($sql_contents) && !empty($database_name)) {
									$database  = $this->account->createDatabase($database_name,$sql_contents,$result);
									//$createCoa = $this->account->CreateDefaultCoa($result); 
									if($database) {
										$sessSuccess = new Zend_Session_Namespace('insert_account_success');
										$sessSuccess->status = 1;
										$sessSuccess->companyId = $result;
										$this->_redirect('index/registration');
									} else{
										$sessSuccess = new Zend_Session_Namespace('insert_account_success_nodb');
										$sessSuccess->status = 1;
										$sessSuccess->companyId = $result;
										$this->_redirect('index/registration');
									}
								} else {
									$sessSuccess = new Zend_Session_Namespace('insert_account_success_nodb');
									$sessSuccess->status = 1;
									$sessSuccess->companyId = $result;
									$this->_redirect('index/registration');
								}
							}  else {
								$this->view->error = 'Company created succesfully. Login details cannot be created. Kindly try adding in user settings';
							}
						} else {
								$this->view->error = 'Account cannot be created. Kindly try again later';
						}
					  } else {
					  		$this->view->error = 'Email ID already exists. Kindly try some other email address';
					  }
				} else {
					$this->view->error = 'Financial start and end date should be exactly one year';
				}
			}

		}
	}

	public function updateProfileAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			$this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_id) && !empty($logSession->proxy_id)) {
				$id = $logSession->proxy_id;
			} else {
				$id = $logSession->id;
			}
			if(Zend_Session::namespaceIsset('update_success_user')) {
				$this->view->success = 'Details Updated Successfully';
				Zend_Session::namespaceUnset('update_success_user');
			}
			$getAccountArray       	   =  $this->accountData->getData(array('account_types'));
			$this->view->account_types =  $getAccountArray['account_types'];
			$this->view->result        =  $this->account->getLoginDetails($id);
			//print_r($this->view->login);
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$checkUsername			= $this->account->checkLogin($postArray['username'],$id);
				if(!$checkUsername) {
					$result					= $this->account->updateLogin($postArray,$id);
					if($result) {
						$sessSuccess = new Zend_Session_Namespace('update_success_user');
						$sessSuccess->status = 1;
						$this->_redirect('index/update-profile');
					} else {
						$this->view->error = 'Details cannot be updated. Kindly try again later';
					} 
				} else {
					$this->view->error = 'Email ID already exists. Kindly try some other email address';
				}
			}
		}
	}

	public function convertCurrencyAction() {
	  $this->_helper->getHelper('layout')->disableLayout();
	  $this->_helper->viewRenderer->setNoRender(true);
	  if($this->_request->isXmlHttpRequest()) {
		if ($this->_request->isPost()) {
		  $ajaxVal = $this->getRequest()->getPost();
			if($ajaxVal['action']=='converter') {
			      $amount = $ajaxVal['amount'];
			      $from   = $ajaxVal['from'];
			      $to     = 'SGD';
			      $url  = "https://www.google.com/finance/converter?a=$amount&from=$from&to=$to";
			      $data = file_get_contents($url);
			      preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
			      $converted = preg_replace("/[^0-9.]/", "", $converted[1]);
			      echo round($converted, 2);
			} 
		} 
	  } 
  	}

	public function logoutAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if($logSession->type!=0) {
			$auditLog	  = $this->settings->insertAuditLog(9,13,'Logged Out',$logSession->type);
		}
		if(Zend_Session::destroy()) {
			$this->_redirect('index');
		} else {
			$this->_redirect('index');
		}
	}
	
}

?>
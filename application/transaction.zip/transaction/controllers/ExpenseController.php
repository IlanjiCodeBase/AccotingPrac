<?php 
class Transaction_ExpenseController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->accountData = new Account_Data();
		$logSession = new Zend_Session_Namespace('sess_login');	
		if($logSession->type==0 && !isset($logSession->companySet)) {
			$this->_redirect('developer');
		}	
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$draftSave  = new Zend_Session_Namespace('draft_save_expense');
			//echo '<pre>'; print_r($_SESSION['draft_save_expense']); echo '</pre>';
			if(isset($draftSave)) {
				$this->view->date 			 =  $draftSave->date;
				$this->view->receipt 	 	 =  $draftSave->receipt;
				$this->view->vendorid	 	 =  $draftSave->vendor;
				$this->view->shippingAddress =  $draftSave->shippingAddress;
				$this->view->credit_term	 =  $draftSave->credit_term;
				$this->view->currencyid		 =  $draftSave->currency;
				$this->view->due_date		 =  $draftSave->due_date;
				$this->view->discount   	 =  $draftSave->discount;
				$this->view->discount_amount =  $draftSave->discount_amount;
				$this->view->permit 		 =  $draftSave->permit;
				$this->view->do_so_no 		 =  $draftSave->do_so_no;
				$this->view->counter 		 =  $draftSave->counter;
			}
			$cid = $logSession->cid;
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				if(isset($postArray['add_payment']) && !empty($postArray['add_payment'])) {
					$postArray['discount'] = 0;
					$postArray['ref_id']   = $postArray['expense_id'];
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
					if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_payment_amount'])) {
						$postArray['discount'] = $postArray['discount_payment_amount'];
					}
					$addPayment = $this->transaction->addPayment($postArray,2);
					if($addPayment) {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 1;
					} else {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 2;
					}
					$this->_redirect('transaction/expense/');
				} else {
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
					$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
					if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,1);
					} else if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,2);
					}
					if($expenseTransaction) {
						$sessSuccess = new Zend_Session_Namespace('insert_success_expense');
						$sessSuccess->status = 1;
						$this->_redirect('transaction/expense/');
					} else {
							$this->view->error = 'Expense Transaction cannot be added. Kindly try again later';
					}
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_expense')) {
				$this->view->success = 'Expense Transaction Added successfully';
				Zend_Session::namespaceUnset('insert_success_expense');
			}
			if(Zend_Session::namespaceIsset('delete_success_expense_transaction')) {
				$this->view->success = 'Transaction deleted successfully';
				Zend_Session::namespaceUnset('delete_success_expense_transaction');
			}
			if(Zend_Session::namespaceIsset('add_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('add_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully added';
					Zend_Session::namespaceUnset('add_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be added. Kindly try again later';
					Zend_Session::namespaceUnset('add_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('verify_success_expense_transaction')) {
				$this->view->success = 'Transaction verified successfully';
				Zend_Session::namespaceUnset('verify_success_expense_transaction');
			}
			if(Zend_Session::namespaceIsset('unverify_success_expense_transaction')) {
				$this->view->success = 'Transaction unverified successfully';
				Zend_Session::namespaceUnset('unverify_success_expense_transaction');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteExpenseTransaction($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_expense_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/expense');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeExpenseTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$sessSuccess = new Zend_Session_Namespace('verify_success_expense_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$sessSuccess = new Zend_Session_Namespace('unverify_success_expense_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/expense');
			}
			$maximum = array();
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(1);
			$this->view->creditSet 		=  1;
			$this->view->maxExpense  	=  $this->transaction->getMaxExpenseTransaction();
			$this->view->result 		=  $this->transaction->getExpenseTransaction();
			$this->view->payments 		=  $this->transaction->getPaymentDetails('',2);
			foreach ($this->view->maxExpense as $max) {
				if(!array_key_exists($max['fkexpense_id'], $maximum)) {
					$maximum[$max['fkexpense_id']]['product_description'] = $max['product_description'];
					$maximum[$max['fkexpense_id']]['account_name'] 		  = $max['account_name'];
				}
			}
			$this->view->maximumExpense = $maximum;
			//echo '<pre>'; print_r($maximum); echo '</pre>';
		}
	}

	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(1);
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['discount'] = 0;
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
					$postArray['discount'] = $postArray['discount_amount'];
				}
				$updatePayment = $this->transaction->updatePayment($postArray,2);
				if($updatePayment) {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 1;
				} else {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 2;
				}
			}
			if(Zend_Session::namespaceIsset('update_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('update_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully updated';
					Zend_Session::namespaceUnset('update_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be updated. Kindly try again later';
					Zend_Session::namespaceUnset('update_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('delete_success_expense_payment')) {
				$this->view->success = 'Expense Payment Deleted successfully';
				Zend_Session::namespaceUnset('delete_success_expense_payment');
			}
			$id = base64_decode($this->_getParam('id'));
			$this->view->exp_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList    =  $this->transaction->getExpenseTransactionList($id);
					$this->view->expensePayment =  $this->transaction->getPaymentDetails($id,2);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
				//echo '<pre>'; print_r($this->view->expensePayment); echo '</pre>';
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deletePayment($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_expense_payment');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/expense/view/id/'.$this->_getParam('id'));
			}			
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_expense')) {
				$this->view->success = 'Expense Transaction Updated successfully';
				Zend_Session::namespaceUnset('update_success_expense');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList  =  $this->transaction->getExpenseTransactionList($id);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
				if(isset($postArray['save_expense']) && !empty($postArray['save_expense'])) {
					$expenseTransaction = $this->transaction->updateExpenseTransaction($postArray,$id,$postArray['transaction_status']);
				} else if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
					$expenseTransaction = $this->transaction->updateExpenseTransaction($postArray,$id,1);
				}
				if($expenseTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_expense');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/expense/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Expense Transaction cannot be updated. Kindly try again later';
				}
				
			}
			//echo '<pre>'; print_r($this->view->expense); echo '</pre>'; 
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(1);
		}
	}

	public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList  =  $this->transaction->getExpenseTransactionList($id);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
				if(isset($postArray['save_expense']) && !empty($postArray['save_expense'])) {
					$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,$postArray['transaction_status']);
				} else if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
					$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,1);
				}
				if($expenseTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_expense');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/expense');
				} else {
						$this->view->error = 'Expense Transaction cannot be added. Kindly try again later';
				}
				
			}
			//echo '<pre>'; print_r($this->view->expense); echo '</pre>'; 
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(1);
		}
	}

	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='save_draft_expense') {
					if(Zend_Session::namespaceIsset('draft_save_expense')) {
						Zend_Session::namespaceUnset('draft_save_expense');
					}
					$sessDraft = new Zend_Session_Namespace('draft_save_expense');
					$sessDraft->date 			= $ajaxVal['date'];
					$sessDraft->receipt 		= $ajaxVal['receipt'];
					$sessDraft->vendor 			= $ajaxVal['vendor'];
					$sessDraft->shippingAddress = $ajaxVal['shipping_address'];
					$sessDraft->credit_term 	= $ajaxVal['credit_term'];
					$sessDraft->currency 		= $ajaxVal['currency'];
					$sessDraft->due_date		= $ajaxVal['due_date'];
					$sessDraft->discount    	= $ajaxVal['payment_discount'];
					if(isset($ajaxVal['discount_amount'])) {
						$sessDraft->discount_amount = $ajaxVal['discount_amount'];
					} else {
						$sessDraft->discount_amount = 0;
					}
					$sessDraft->permit  		= $ajaxVal['permit_no'];
					$sessDraft->do_so_no  		= $ajaxVal['do_so_no'];
					$sessDraft->counter 		= $ajaxVal['expense_counter'];
					if(isset($sessDraft->counter) && !empty($sessDraft->counter) && $sessDraft->counter!=0) {
						for ($i=1; $i <= $sessDraft->counter; $i++) { 
							$sessDraft->tax_id[$i] 			     = '';
							$sessDraft->tax_percentage[$i] 	 	 = '';
							$sessDraft->expense_type[$i]   	 	 =  $ajaxVal['expense_type_'.$i];
							$sessDraft->product_id[$i]    		 =  trim($ajaxVal['product_id_'.$i]);
							$sessDraft->product_description[$i]  =  trim($ajaxVal['product_description_'.$i]);
							$sessDraft->quantity[$i]   	 	 	 =  trim($ajaxVal['quantity_'.$i]);
							$sessDraft->price[$i]    			 =  trim($ajaxVal['price_'.$i]);
							if($ajaxVal['tax_code_'.$i]==0 || $ajaxVal['tax_code_'.$i]=='') {
								$sessDraft->tax_id[$i]  = '';
								$sessDraft->tax_percentage[$i] = '';
							} else {
								$taxes  			 = 	explode("_",$ajaxVal['tax_code_'.$i]);
								$sessDraft->tax_id[$i] 	 =  $taxes[0];
								if(isset($taxes[1]) && !empty($taxes[1])) {
									$sessDraft->tax_percentage[$i] = $taxes[1];
								}
							}
						  
						}
					} 
					if(isset($sessDraft)) {
						echo "success";
					} else {
						echo "Failure";
					}
				} else if($ajaxVal['action']=='save_draft_income_copy') {
					if(Zend_Session::namespaceIsset('draft_save_expense')) {
						Zend_Session::namespaceUnset('draft_save_expense');
					}
					$sessDraft = new Zend_Session_Namespace('draft_save_income');
					$sessDraft->date 		= $ajaxVal['date'];
					$sessDraft->receipt 	= $ajaxVal['receipt'];
					$sessDraft->customer 	= $ajaxVal['customer'];
					$sessDraft->payaccount 	= $ajaxVal['pay_account'];
					$sessDraft->credit_term = $ajaxVal['credit_term'];
					$sessDraft->currency 	= $ajaxVal['currency'];
					$sessDraft->income_type = $ajaxVal['income_type'];
					$sessDraft->description = $ajaxVal['description'];
					$sessDraft->amount 		= $ajaxVal['amount'];
					$tax_id = ' ';
					$tax_percentage = ' ';
					$taxes = explode("_",$ajaxVal['tax_code']);
					$tax_id = $taxes[0];
					if(isset($taxes[1]) && !empty($taxes[1])) {
						$tax_percentage = $taxes[1];
					}
					$sessDraft->tax_code 	= $tax_id;
					if(isset($sessDraft)) {
						echo "success";
					} else {
						echo "Failure";
					}
				}
			}
		} 
	}


		
}

?>
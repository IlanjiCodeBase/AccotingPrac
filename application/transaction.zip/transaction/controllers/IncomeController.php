<?php 
class Transaction_IncomeController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->accountData = new Account_Data();
		$logSession = new Zend_Session_Namespace('sess_login');	
		if($logSession->type==0 && !isset($logSession->companySet)) {
			$this->_redirect('developer');
		}	
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$draftSave  = new Zend_Session_Namespace('draft_save_income');
			if(isset($draftSave)) {
				$this->view->date 		 =  $draftSave->date;
				$this->view->receipt 	 =  $draftSave->receipt;
				$this->view->customerid	 =  $draftSave->customer;
				$this->view->payid	 	 =  $draftSave->payaccount;
				$this->view->credit_term =  $draftSave->credit_term;
				$this->view->currencyid	 =  $draftSave->currency;
				$this->view->income_type =  $draftSave->income_type;
				$this->view->description =  $draftSave->description;
				$this->view->amount 	 =  $draftSave->amount;
				$this->view->tax_code 	 =  $draftSave->tax_code;
			}
			$cid = $logSession->cid;
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				if(isset($postArray['add_payment']) && !empty($postArray['add_payment'])) {
					$postArray['discount'] = 0;
					$postArray['ref_id']   = $postArray['income_id'];
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
					if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_payment_amount'])) {
						$postArray['discount'] = $postArray['discount_payment_amount'];
					}
					$addPayment = $this->transaction->addPayment($postArray,1);
					if($addPayment) {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 1;
					} else {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 2;
					}
					$this->_redirect('transaction/income/');
				} else {
					$postArray['tax_id'] = ' ';
					$postArray['tax_percentage'] = ' ';
					$postArray['date'] = date("Y-m-d",strtotime(trim($postArray['date'])));
					$taxes = explode("_",$postArray['tax_code']);
					$postArray['tax_id'] = $taxes[0];
					if(isset($taxes[1]) && !empty($taxes[1])) {
						$postArray['tax_percentage'] = $taxes[1];
					}
					//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
					 if(isset($postArray['approve_income']) && !empty($postArray['approve_income'])) {
						$incomeTransaction = $this->transaction->insertIncomeTransaction($postArray,$cid,1);
					}  else if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
						$incomeTransaction = $this->transaction->insertIncomeTransaction($postArray,$cid,2);
					}
					if($incomeTransaction) {
						$sessSuccess = new Zend_Session_Namespace('insert_success_income');
						$sessSuccess->status = 1;
						$this->_redirect('transaction/income/');
					} else {
							$this->view->error = 'Income Transaction cannot be added. Kindly try again later';
					}
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_income')) {
				$this->view->success = 'Income Transaction Added successfully';
				Zend_Session::namespaceUnset('insert_success_income');
			}
			if(Zend_Session::namespaceIsset('delete_success_income_transaction')) {
				$this->view->success = 'Transaction deleted successfully';
				Zend_Session::namespaceUnset('delete_success_income_transaction');
			}
			if(Zend_Session::namespaceIsset('add_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('add_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully added';
					Zend_Session::namespaceUnset('add_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be added. Kindly try again later';
					Zend_Session::namespaceUnset('add_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('verify_success_income_transaction')) {
				$this->view->success = 'Transaction verified successfully';
				Zend_Session::namespaceUnset('verify_success_income_transaction');
			}
			if(Zend_Session::namespaceIsset('unverify_success_income_transaction')) {
				$this->view->success = 'Transaction unverified successfully';
				Zend_Session::namespaceUnset('unverify_success_income_transaction');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteIncomeTransaction($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_income_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/income');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeIncomeTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$sessSuccess = new Zend_Session_Namespace('verify_success_income_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$sessSuccess = new Zend_Session_Namespace('unverify_success_income_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/income');
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->incomeAccount	=  $this->transaction->getIncomeAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$this->view->result 		=  $this->transaction->getIncomeTransaction();
			$this->view->payments 		=  $this->transaction->getPaymentDetails('',1);
			//echo '<pre>'; print_r($this->view->result); echo '</pre>'; die();
		}
	}

	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['discount'] = 0;
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
					$postArray['discount'] = $postArray['discount_amount'];
				}
				$updatePayment = $this->transaction->updatePayment($postArray,1);
				if($updatePayment) {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 1;
				} else {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 2;
				}
			}
			if(Zend_Session::namespaceIsset('update_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('update_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully updated';
					Zend_Session::namespaceUnset('update_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be updated. Kindly try again later';
					Zend_Session::namespaceUnset('update_payment_success');
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->incomeAccount	=  $this->transaction->getIncomeAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$id = base64_decode($this->_getParam('id'));
			$this->view->inc_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/income');
			} else {
				$this->view->income  =  $this->transaction->getIncomeTransaction($id);
				if(!$this->view->income) {
					$this->_redirect('transaction/income');
				}  else {
					$this->view->incomePayment =  $this->transaction->getPaymentDetails($id,1);
				}
			}
			
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_income')) {
				$this->view->success = 'Income Transaction Updated successfully';
				Zend_Session::namespaceUnset('update_success_income');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/income');
			} else {
				$this->view->income  =  $this->transaction->getIncomeTransaction($id);
				if(!$this->view->income) {
					$this->_redirect('transaction/income');
				} 
			}
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['tax_id'] = ' ';
				$postArray['tax_percentage'] = ' ';
				$postArray['date'] = date("Y-m-d",strtotime(trim($postArray['date'])));
				$taxes = explode("_",$postArray['tax_code']);
				$postArray['tax_id'] = $taxes[0];
				if(isset($taxes[1]) && !empty($taxes[1])) {
					$postArray['tax_percentage'] = $taxes[1];
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
				if(isset($postArray['save_income']) && !empty($postArray['save_income'])) {
					$incomeTransaction = $this->transaction->updateIncomeTransaction($postArray,$id,$postArray['transaction_status']);
				} else if(isset($postArray['approve_income']) && !empty($postArray['approve_income'])) {
					$incomeTransaction = $this->transaction->updateIncomeTransaction($postArray,$id,1);
				}
				if($incomeTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_income');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/income/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Income Transaction cannot be updated. Kindly try again later';
				}
				
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->incomeAccount	=  $this->transaction->getIncomeAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			//echo '<pre>'; print_r($this->view->income); echo '</pre>'; 
		}
	}


	public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/income');
			} else {
				$this->view->income  =  $this->transaction->getIncomeTransaction($id);
				if(!$this->view->income) {
					$this->_redirect('transaction/income');
				} 
			}
			if($this->_request->isPost()) {
					$postArray  				= $this->getRequest()->getPost();
					$postArray['tax_id'] = ' ';
					$postArray['tax_percentage'] = ' ';
					$postArray['date'] = date("Y-m-d",strtotime(trim($postArray['date'])));
					$taxes = explode("_",$postArray['tax_code']);
					$postArray['tax_id'] = $taxes[0];
					if(isset($taxes[1]) && !empty($taxes[1])) {
						$postArray['tax_percentage'] = $taxes[1];
					}
					//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
					 if(isset($postArray['approve_income']) && !empty($postArray['approve_income'])) {
						$incomeTransaction = $this->transaction->insertIncomeTransaction($postArray,$cid,1);
					}  else if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
						$incomeTransaction = $this->transaction->insertIncomeTransaction($postArray,$cid,2);
					}
					if($incomeTransaction) {
						$sessSuccess = new Zend_Session_Namespace('insert_success_income');
						$sessSuccess->status = 1;
						$this->_redirect('transaction/income/');
					} else {
							$this->view->error = 'Income Transaction cannot be added. Kindly try again later';
					}
				
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->incomeAccount	=  $this->transaction->getIncomeAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			//echo '<pre>'; print_r($this->view->income); echo '</pre>'; 
		}
	}

	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='save_draft_income') {
					if(Zend_Session::namespaceIsset('draft_save_income')) {
						Zend_Session::namespaceUnset('draft_save_income');
					}
					$sessDraft = new Zend_Session_Namespace('draft_save_income');
					$sessDraft->date 		= $ajaxVal['date'];
					$sessDraft->receipt 	= $ajaxVal['receipt'];
					$sessDraft->customer 	= $ajaxVal['customer'];
					$sessDraft->payaccount 	= $ajaxVal['pay_account'];
					$sessDraft->credit_term = $ajaxVal['credit_term'];
					$sessDraft->currency 	= $ajaxVal['currency'];
					$sessDraft->income_type = $ajaxVal['income_type'];
					$sessDraft->description = $ajaxVal['description'];
					$sessDraft->amount 		= $ajaxVal['amount'];
					$tax_id = ' ';
					$tax_percentage = ' ';
					$taxes = explode("_",$ajaxVal['tax_code']);
					$tax_id = $taxes[0];
					if(isset($taxes[1]) && !empty($taxes[1])) {
						$tax_percentage = $taxes[1];
					}
					$sessDraft->tax_code 	= $tax_id;
					if(isset($sessDraft)) {
						echo "success";
					} else {
						echo "Failure";
					}
				} else if($ajaxVal['action']=='save_draft_income_copy') {
					if(Zend_Session::namespaceIsset('draft_save_income')) {
						Zend_Session::namespaceUnset('draft_save_income');
					}
					$sessDraft = new Zend_Session_Namespace('draft_save_income');
					$sessDraft->date 		= $ajaxVal['date'];
					$sessDraft->receipt 	= $ajaxVal['receipt'];
					$sessDraft->customer 	= $ajaxVal['customer'];
					$sessDraft->payaccount 	= $ajaxVal['pay_account'];
					$sessDraft->credit_term = $ajaxVal['credit_term'];
					$sessDraft->currency 	= $ajaxVal['currency'];
					$sessDraft->income_type = $ajaxVal['income_type'];
					$sessDraft->description = $ajaxVal['description'];
					$sessDraft->amount 		= $ajaxVal['amount'];
					$tax_id = ' ';
					$tax_percentage = ' ';
					$taxes = explode("_",$ajaxVal['tax_code']);
					$tax_id = $taxes[0];
					if(isset($taxes[1]) && !empty($taxes[1])) {
						$tax_percentage = $taxes[1];
					}
					$sessDraft->tax_code 	= $tax_id;
					if(isset($sessDraft)) {
						echo "success";
					} else {
						echo "Failure";
					}
				}
			}
		} 
	}

		
}

?>
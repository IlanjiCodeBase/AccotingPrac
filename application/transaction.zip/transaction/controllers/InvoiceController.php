<?php 
class Transaction_InvoiceController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->settings    = new Settings();
		$this->accountData = new Account_Data();
		$logSession = new Zend_Session_Namespace('sess_login');	
		if($logSession->type==0 && !isset($logSession->companySet)) {
			$this->_redirect('developer');
		}	
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
			// If an unmatched 'Action' method was requested, pass on to the
			// default action method:
			if ('Action' == substr($method, -6)) {
				return $this->_redirect('index/error/');
			}
			throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['discount'] = 0;
				$postArray['ref_id']   = $postArray['invoice_id'];
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
					$postArray['discount'] = $postArray['discount_amount'];
				}
				$addPayment = $this->transaction->addPayment($postArray,3);
				if($addPayment) {
					$sessSuccess = new Zend_Session_Namespace('add_payment_success');
					$sessSuccess->status = 1;
				} else {
					$sessSuccess = new Zend_Session_Namespace('add_payment_success');
					$sessSuccess->status = 2;
				}
				$this->_redirect('transaction/invoice/');
			}
			if(Zend_Session::namespaceIsset('insert_success_invoice')) {
				$this->view->success = 'Invoice Added successfully';
				Zend_Session::namespaceUnset('insert_success_invoice');
			}
			if(Zend_Session::namespaceIsset('delete_success_invoice_transaction')) {
				$this->view->success = 'Invoice deleted successfully';
				Zend_Session::namespaceUnset('delete_success_invoice_transaction');
			}
			if(Zend_Session::namespaceIsset('mark_success_invoice_transaction')) {
				$this->view->success = 'Invoice marked successfully';
				Zend_Session::namespaceUnset('mark_success_invoice_transaction');
			}
			if(Zend_Session::namespaceIsset('add_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('add_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully added';
					Zend_Session::namespaceUnset('add_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be added. Kindly try again later';
					Zend_Session::namespaceUnset('add_payment_success');
				}
			}
			$sentid = base64_decode($this->_getParam('sentid'));
			if(isset($sentid) && !empty($sentid)) {
				$markStatus = $this->transaction->markInvoiceTransaction($sentid,3);
				if($markStatus) {
					$sessSuccess = new Zend_Session_Namespace('mark_success_invoice_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/invoice');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteInvoiceTransaction($delid,3);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_invoice_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/invoice');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeExpenseTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$sessSuccess = new Zend_Session_Namespace('verify_success_expense_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$sessSuccess = new Zend_Session_Namespace('unverify_success_expense_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/invoice');
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(1);
			$this->view->result 		=  $this->transaction->getInvoiceTransaction();
			$this->view->payments 		=  $this->transaction->getPaymentDetails('',3);
			//echo '<pre>'; print_r($this->view->payments); echo '</pre>';
		}
	}

	public function addAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$this->view->customer_id = base64_decode($this->_getParam('cid'));
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,4);
				} else if(isset($postArray['approve_invoice']) && !empty($postArray['approve_invoice'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,1);
				} else if(isset($postArray['save_sent']) && !empty($postArray['save_sent'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,3);
				}
				if($invoiceTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_invoice');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/invoice/');
				} else {
						$this->view->error = 'Invoice cannot be added. Kindly try again later';
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_invoice')) {
				$this->view->success = 'Invoice Added successfully';
				Zend_Session::namespaceUnset('insert_success_invoice');
			}
			
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->invoiceNo    	=  $this->transaction->generateInvoiceNo();
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->shipping 		=  $this->transaction->getShippingDetails();
			$this->view->product 		=  $this->transaction->getProductDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
			//echo '<pre>'; print_r($this->view->product); echo '</pre>';
			//echo '<pre>'; print_r($this->view->shipping); echo '</pre>';
		}
	}

	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['discount'] = 0;
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
					$postArray['discount'] = $postArray['discount_amount'];
				}
				$updatePayment = $this->transaction->updatePayment($postArray,3);
				if($updatePayment) {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 1;
				} else {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 2;
				}
			}
			if(Zend_Session::namespaceIsset('update_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('update_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully updated';
					Zend_Session::namespaceUnset('update_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be updated. Kindly try again later';
					Zend_Session::namespaceUnset('update_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('delete_success_invoice_payment')) {
				$this->view->success = 'Invoice Payment Deleted successfully';
				Zend_Session::namespaceUnset('delete_success_invoice_payment');
			}
			$id = base64_decode($this->_getParam('id'));
			$this->view->inv_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/invoice');
			} else {
				$this->view->invoice  =  $this->transaction->getInvoiceTransaction($id);
				if(!$this->view->invoice) {
					$this->_redirect('transaction/invoice');
				} else {
					$this->view->invoiceProductList  =  $this->transaction->getInvoiceProductList($id);
					$this->view->invoicePayment      =  $this->transaction->getPaymentDetails($id,3);
					if(!$this->view->invoiceProductList) {
						$this->_redirect('transaction/invoice');
					} 
				}
			}	
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deletePayment($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_invoice_payment');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/invoice/view/id/'.$this->_getParam('id'));
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->shipping 		=  $this->transaction->getShippingDetails();
			$this->view->product 		=  $this->transaction->getProductDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_invoice')) {
				$this->view->success = 'Invoice Updated successfully';
				Zend_Session::namespaceUnset('update_success_invoice');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/invoice');
			} else {
				$this->view->invoice  =  $this->transaction->getInvoiceTransaction($id);
				if(!$this->view->invoice) {
					$this->_redirect('transaction/invoice');
				} else {
					$this->view->invoiceProductList  =  $this->transaction->getInvoiceProductList($id);
					if(!$this->view->invoiceProductList) {
						$this->_redirect('transaction/invoice');
					} 
				}
			}	
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
				if(isset($postArray['save_invoice']) && !empty($postArray['save_invoice'])) {
					$invoiceTransaction = $this->transaction->updateInvoiceTransaction($postArray,$id,$postArray['invoice_status']);
				} 
				if($invoiceTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_invoice');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/invoice/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Invoice cannot be updated. Kindly try again later';
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->shipping 		=  $this->transaction->getShippingDetails();
			$this->view->product 		=  $this->transaction->getProductDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
			echo '<pre>'; print_r($this->view->invoice); echo '</pre>';
		}
	}

	public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('insert_success_invoice')) {
				$this->view->success = 'Invoice Added successfully';
				Zend_Session::namespaceUnset('insert_success_invoice');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			$cid = $logSession->cid;
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/invoice');
			} else {
				$this->view->invoice  =  $this->transaction->getInvoiceTransaction($id);
				if(!$this->view->invoice) {
					$this->_redirect('transaction/invoice');
				} else {
					$this->view->invoiceProductList  =  $this->transaction->getInvoiceProductList($id);
					if(!$this->view->invoiceProductList) {
						$this->_redirect('transaction/invoice');
					} 
				}
			}	
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));
				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,4);
				} else if(isset($postArray['approve_invoice']) && !empty($postArray['approve_invoice'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,1);
				} else if(isset($postArray['save_sent']) && !empty($postArray['save_sent'])) {
					$invoiceTransaction = $this->transaction->insertInvoiceTransaction($postArray,$cid,3);
				}
				if($invoiceTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_invoice');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/invoice/copy/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Invoice cannot be added. Kindly try again later';
				}
			}
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->invoiceNo    	=  $this->transaction->generateInvoiceNo();
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->customer 		=  $this->transaction->getCustomerDetails();
			$this->view->shipping 		=  $this->transaction->getShippingDetails();
			$this->view->product 		=  $this->transaction->getProductDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax(2);
			$this->view->product 	    =  $this->settings->getProducts();
			$this->view->creditSet 		=  1;
		}
	}

	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		$action = $this->_getParam('ajaxAction');
		if($action=='copy_transaction') {
			$id  = base64_decode($this->_getParam('tid'));
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->currencies     =  $getAccountArray['currencies'];
			$this->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->payAccount	  =  $this->transaction->getPaymentAccount();
			$this->customer 	  =  $this->transaction->getCustomerDetails();
			$this->incomeAccount  =  $this->transaction->getIncomeAccount();
			$this->taxCode    	  =  $this->transaction->getTax(2);
			$this->income  		  =  $this->transaction->getIncomeTransaction($id);
			if($this->income) {
                echo '<div class="form-group">';
                echo '<div class="col-lg-3">';
                echo '<label>Date <span class="mandatory">*</span></label>';
                echo '<input type="text" name="date" id="date" class="form-control date-pick" placeholder="Select Date" value="'.date('d-m-Y',strtotime($this->income[0]['date'])).'" />';
                echo '<input type="hidden" name="transaction_status" id="transaction_status" value="'.$this->income[0]['transaction_status'].'">';
                echo '</div>';
                                             
                echo '<div class="col-lg-3">';
                echo '<label>Receipt No <span class="mandatory">*</span></label>';
                echo '<input type="text" name="receipt" id="receipt" class="form-control" placeholder="Enter Receipt No" value="'.$this->income[0]['receipt_no'].'" />';
                echo '</div>';    
                echo '<div class="col-lg-2">';
                echo '<label>Customer / Payee <span class="mandatory">*</span></label>';
                echo '<select class="select2" name="customer">';
                    if(isset($this->customer) && !empty($this->customer)) {
                        foreach ($this->customer as $customer) {
                            if($customer['id']==$this->income[0]['fkcustomer_id'])
                                $customerSelect = 'selected';
                            else
                            $customerSelect = '';
                echo '<option value="'.$customer['id'].'" '.$customerSelect.'>'.$customer['customer_name'].'</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';
                echo '<div class="col-lg-2">';
                echo '<label>Payment Account <span class="mandatory">*</span></label>';
                echo '<select class="select2" name="pay_account">';
                    if(isset($this->payAccount) && !empty($this->payAccount)) {
                        foreach ($this->payAccount as $pay) {
                            if($pay['id']==$this->income[0]['fkpayment_account'])
                                $paySelect = 'selected';
                            else
                                $paySelect = '';
                echo '<option value="'.$pay['id'].'" '.$paySelect.'>'.$pay['account_name'].'</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';
                echo '<div class="col-lg-2">';
                echo '<label>Credit Term <span class="mandatory">*</span></label>';
                echo '<select class="select2" name="credit_term">';
                    if(isset($this->creditTerm) && !empty($this->creditTerm)) {
                        foreach ($this->creditTerm as $key => $credit) {
                            if($key==$this->income[0]['credit_term'])
                                $creditSelect = 'selected';
                            else
                                $creditSelect = '';
                echo '<option value="'.$key.'" '.$creditSelect.'>'.$credit.'</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';
                echo '</div>';

                echo '<div class="form-group">';

                echo '<div class="col-lg-2">';
                echo '<label>Currency <span class="mandatory">*</span></label>';
                echo '<select class="select2" name="currency">';
                    if(isset($this->currencies) && !empty($this->currencies)) {
                        foreach ($this->currencies as $key => $currency) {
                            if($key==$this->income[0]['transaction_currency']) 
                                $currencySelect = "selected";
                            else
                                $currencySelect = "";
                echo '<option value="'.$key.'" '.$currencySelect.'>'.$currency.'</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';

                echo '<div class="col-lg-2">';
                echo '<label>Type of Income <span class="mandatory">*</span></label>';
                echo '<select class="select2" name="income_type">';
                    if(isset($this->incomeAccount) && !empty($this->incomeAccount)) {
                        foreach ($this->incomeAccount as $income) {
                            if($income['id']==$this->income[0]['fkincome_type']) 
                                $incomeSelect = "selected";
                            else
                                $incomeSelect = "";
                echo '<option value="'.$income['id'].'" '.$incomeSelect.'>'.$income['account_name'].'</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';

                echo '<div class="col-lg-4">';
                echo '<label>Description <span class="mandatory">*</span></label>';
                echo '<input type="text" name="description" id="description" class="form-control" placeholder="Enter Description" value="'.$this->income[0]['transaction_description'].'">';
                echo '</div>'; 

                echo '<div class="col-lg-2">';
                echo '<label>Amount <span class="mandatory">*</span></label>';
                echo '<input type="text" name="amount" id="amount" class="form-control" placeholder="Enter Amount" value="'.$this->income[0]['amount'].'">';
                echo '</div>';

                echo '<div class="col-lg-2">';
                echo '<label>Tax Code </label>';
                echo '<select class="select2" name="tax_code">';
                echo '<option value="">Select</option>';    
                    if(isset($this->taxCode) && !empty($this->taxCode)) {
                        foreach ($this->taxCode as $tax) {
                            if($tax['id']==$this->income[0]['fktax_id']) 
                                $taxSelect = "selected";
                            else
                                $taxSelect = "";
                echo '<option value="'.$tax['id']."_".$tax['tax_percentage'].'" '.$taxSelect.'>'.$tax['tax_code'].'-'.$tax['tax_percentage'].' %</option>';
                        }
                    }
                echo '</select>';
                echo '</div>';

                echo '</div>';

                echo '<div class="form-group">';
                echo '<div class="col-lg-3">';
                echo '<div class="form-actions">';
                echo '<input type="submit" name="save_income" class="btn btn-primary copy_income_transaction" id="save_income" value="Save" />';
                echo ' <input type="submit" name="approve_income" class="btn btn-primary copy_income_transaction" id="approve_income" value="Save & Approve" />';
                echo ' <button type="reset" class="btn">Cancel</button>';
                echo '</div>';
                echo '</div>';
                echo '</div>';

			}
		}
	}

		
}

?>
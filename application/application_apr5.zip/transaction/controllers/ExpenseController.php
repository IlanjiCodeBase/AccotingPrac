<?php 
require_once "Account/Uploader.php";
class Transaction_ExpenseController extends Zend_Controller_Action {
	/**
     * @var result
    */
	protected $result;
	
	/**
    * @var $postArray
    */
	protected $postArray;
	
	public function init() {
		$this->root 	   = Zend_Registry::get('path');
		$this->uploadPath  = Zend_Registry::get('uploadpath');
		$this->receiptPath = Zend_Registry::get('receiptuploadpath');
		$this->business    = new Business();
		$this->transaction = new Transaction();
		$this->settings    = new Settings();
		$this->approval    = new Approval();
		$this->accountData = new Account_Data();
		if(Zend_Session::namespaceIsset('sess_login')) {
			$logSession = new Zend_Session_Namespace('sess_login');	
			if($logSession->type==0 && !isset($logSession->proxy_type)) {
				$this->_redirect('developer');
			} 	
		} else {
			$this->_redirect('index');
		}	

			$logSession = new Zend_Session_Namespace('sess_login');

			if(isset($logSession->proxy_id) && !empty($logSession->proxy_id)) {
				$id = $logSession->proxy_id;
			} else {
				$id = $logSession->id;
			}

			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}

			$notify = array();
			$countMessage = 0; 
			$countUnseenMessage = 0; 


			$this->notifications = $this->approval->getNotificationMessage($cid,$id);
			if(isset($this->notifications) && !empty($this->notifications)) {
				foreach ($this->notifications as $notification) {
					$users 			= explode(",", $notification['users']);
					$seen_users 	= explode(",", $notification['seen_users']);
					if(in_array($id,$users)) {
						if(in_array($id, $seen_users)) {
							$notify[$notification['id']]['seen'] = 1;
						} else {
							$notify[$notification['id']]['seen'] = 2;
							$countUnseenMessage++;
						}
						$countMessage++; 
						$notify[$notification['id']]['subject'] = $notification['subject'];
						$notify[$notification['id']]['message'] = $notification['message'];
						$notify[$notification['id']]['date']    = $notification['date_created'];
					}
				}
			}

			$this->view->notifyMessage  	   = $countMessage;
			$this->view->notifyUnseenMessage   = $countUnseenMessage;
			$this->view->notifyHeaderMessage   = $notify;
 	}

	/**
    * @param $method action
    */
	
	public function __call($method, $args) {
		// If an unmatched 'Action' method was requested, pass on to the
		// default action method:
		if ('Action' == substr($method, -6)) {
			return $this->_redirect('index/error/');
		}
		throw new Zend_Controller_Exception('Invalid method called');
	}
	
	public function indexAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$sort   = $this->_getParam('sort');
			if(isset($sort) && !empty($sort) && ($sort==1 || $sort==2)) {
				$sort   = $this->_getParam('sort');
			} else {
				$sort = '';
			}

			$this->view->sort = $sort;
			$this->view->filepath    =  $this->uploadPath.$cid."/receipts/";
			$this->view->nextId 	 =  $this->transaction->getNextExpenseTransaction();
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				if(isset($postArray['add_payment']) && !empty($postArray['add_payment'])) {
					$postArray['discount'] = 0;
					$postArray['ref_id']   = $postArray['expense_id'];
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
					if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_payment_amount'])) {
						$postArray['discount'] = $postArray['discount_payment_amount'];
					}
					$addPayment = $this->transaction->addPayment($postArray,2);
					$accountEntry = $this->transaction->accountEntry($postArray['ref_id'],2);
					if($addPayment) {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 1;
					} else {
						$sessSuccess = new Zend_Session_Namespace('add_payment_success');
						$sessSuccess->status = 2;
					}
					$this->_redirect('transaction/expense/');
				} else {
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
					$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));

					/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
					$fileInfo 	=  $adapter->getFileInfo('file'); 
					if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
						$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
						        ->addValidator('Size',false,array('max'=>2024000),'file')
								->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
						$adapter->setDestination("..".$this->view->filepath,'file');
						$fileInfo 	         	  =   $adapter->getFileInfo('file');
						$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
						$postArray['extension']   =   $fileArray['1'];
						$renameFile 		  	  =   trim($this->view->nextId."_".rand(10,10000)."_".$this->view->nextId.".".$fileArray['1']);
						$postArray['receipt_id']  =   $renameFile;
						$adapter->addFilter('Rename',"..".$this->view->filepath.$renameFile);
							if ($adapter->isValid('file') && $adapter->receive('file')) {
								$postArray['receipt_id'] =   $renameFile;
							} else {
								$postArray['receipt_id'] =   '';
							}
					} else {
						$postArray['receipt_id'] =   '';
					}*/
					$payment_account = explode("_", $postArray['payment_account']);
					$postArray['pay_account'] = $payment_account[0];
					if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
						$postArray['approval_for'] = $logSession->id;
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,1);
					} else if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,2);
					}
					if($expenseTransaction) {
						$sessSuccess = new Zend_Session_Namespace('insert_success_expense');
						$sessSuccess->status = 1;
						$this->_redirect('transaction/expense/');
					} else {
							$this->view->error = 'Expense Transaction cannot be added. Kindly try again later';
					}
				}
				//echo '<pre>'; print_r($postArray); echo '</pre>'; die();
			}
			if(Zend_Session::namespaceIsset('insert_success_expense')) {
				$this->view->success = 'Expense Transaction Added successfully';
				Zend_Session::namespaceUnset('insert_success_expense');
			}
			if(Zend_Session::namespaceIsset('delete_success_expense_transaction')) {
				$this->view->success = 'Transaction deleted successfully';
				Zend_Session::namespaceUnset('delete_success_expense_transaction');
			}
			if(Zend_Session::namespaceIsset('add_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('add_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully added';
					Zend_Session::namespaceUnset('add_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be added. Kindly try again later';
					Zend_Session::namespaceUnset('add_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('verify_success_expense_transaction')) {
				$this->view->success = 'Transaction verified successfully';
				Zend_Session::namespaceUnset('verify_success_expense_transaction');
			}
			if(Zend_Session::namespaceIsset('unverify_success_expense_transaction')) {
				$this->view->success = 'Transaction unverified successfully';
				Zend_Session::namespaceUnset('unverify_success_expense_transaction');
			}

			if(Zend_Session::namespaceIsset('sess_draft_expense_insert')) {
				$this->view->success = 'Expense Transaction saved as draft';
				Zend_Session::namespaceUnset('sess_draft_expense_insert');
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deleteExpenseTransaction($delid,2);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_expense_transaction');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/expense');
			}
			$verifyid  = base64_decode($this->_getParam('verifyid'));
			$status    = $this->_getParam('status');
			if(isset($verifyid) && !empty($verifyid) && isset($status) && !empty($status)) {
				$changeStatus = $this->transaction->changeExpenseTransactionStatus($verifyid,$status);
				if($changeStatus) {
					if($status==1) {
						$accountEntry = $this->transaction->accountEntry($verifyid,2);
						$sessSuccess = new Zend_Session_Namespace('verify_success_expense_transaction');
						$sessSuccess->status = 1;
					} else if($status==2) {
						$accountEntryExpired = $this->transaction->accountEntryExpired($verifyid,2);
						$sessSuccess = new Zend_Session_Namespace('unverify_success_expense_transaction');
						$sessSuccess->status = 2;
					}
				}
					$this->_redirect('transaction/expense');
			}
			$maximum = array();
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->receipts 		=  $this->business->getReceipts('',2);
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax();
			$this->view->creditSet 		=  1;
			$this->view->maxExpense  	=  $this->transaction->getMaxExpenseTransaction();
			$this->view->result 		=  $this->transaction->getExpenseTransaction($id='',$sort);
			$this->view->payments 		=  $this->transaction->getPaymentDetails('',2);
			foreach ($this->view->maxExpense as $max) {
				if(!array_key_exists($max['fkexpense_id'], $maximum)) {
					$maximum[$max['fkexpense_id']]['product_description'] = $max['product_description'];
					$maximum[$max['fkexpense_id']]['account_name'] 		  = $max['account_name'];
				}
			}
			$this->view->maximumExpense = $maximum;
			//echo '<pre>'; print_r($maximum); echo '</pre>';
		}
	}

	public function viewAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->filepath    	=  $this->uploadPath.$cid."/receipts/";
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->approveUser	=  $this->settings->getApproveUsers();
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->receipts 		=  $this->business->getReceipts('',2);
			$this->view->taxCode    	=  $this->transaction->getTax();
			if($this->_request->isPost()) {
				$postArray  				= $this->getRequest()->getPost();
				$postArray['discount'] = 0;
				$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
					$postArray['discount'] = $postArray['discount_amount'];
				}
				$updatePayment = $this->transaction->updatePayment($postArray,2);
				if($updatePayment) {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 1;
				} else {
					$sessSuccess = new Zend_Session_Namespace('update_payment_success');
					$sessSuccess->status = 2;
				}
			}
			if(Zend_Session::namespaceIsset('update_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('update_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully updated';
					Zend_Session::namespaceUnset('update_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be updated. Kindly try again later';
					Zend_Session::namespaceUnset('update_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('delete_success_expense_payment')) {
				$this->view->success = 'Expense Payment Deleted successfully';
				Zend_Session::namespaceUnset('delete_success_expense_payment');
			}
			$id = base64_decode($this->_getParam('id'));
			$this->view->exp_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList    =  $this->transaction->getExpenseTransactionList($id);
					$this->view->expensePayment =  $this->transaction->getPaymentDetails($id,2);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
				//echo '<pre>'; print_r($this->view->expensePayment); echo '</pre>';
			}
			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deletePayment($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_expense_payment');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/expense/view/id/'.$this->_getParam('id'));
			}			
		}
	}


	public function editAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			if(Zend_Session::namespaceIsset('update_success_expense')) {
				$this->view->success = 'Expense Transaction Updated successfully';
				Zend_Session::namespaceUnset('update_success_expense');
			}
			if(Zend_Session::namespaceIsset('update_payment_success')) {
				$sessCheck = new Zend_Session_Namespace('update_payment_success');
				if($sessCheck->status==1) {
					$this->view->success = 'Payment successfully updated';
					Zend_Session::namespaceUnset('update_payment_success');
				} else if($sessCheck->status==2) {
					$this->view->error = 'Payment cannot be updated. Kindly try again later';
					Zend_Session::namespaceUnset('update_payment_success');
				}
			}
			if(Zend_Session::namespaceIsset('delete_success_expense_payment')) {
				$this->view->success = 'Expense Payment Deleted successfully';
				Zend_Session::namespaceUnset('delete_success_expense_payment');
			}
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->filepath    =  $this->uploadPath.$cid."/receipts/";
			$id = base64_decode($this->_getParam('id'));
			$this->view->exp_id = $id;
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList  =  $this->transaction->getExpenseTransactionList($id);
					$this->view->expensePayment =  $this->transaction->getPaymentDetails($id,2);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				if(isset($postArray['action']) && $postArray['action']=='add_payment') {
					$postArray['discount'] = 0;
					$postArray['date'] 	   = date("Y-m-d",strtotime(trim($postArray['pay_date'])));
					if(isset($postArray['payment_discount']) && $postArray['payment_discount']==1 && isset($postArray['discount_amount'])) {
						$postArray['discount'] = $postArray['discount_amount'];
					}
					$updatePayment = $this->transaction->updatePayment($postArray,2);
					$accountEntry  = $this->transaction->accountEntry($id,2);
					if($updatePayment) {
						$sessSuccess = new Zend_Session_Namespace('update_payment_success');
						$sessSuccess->status = 1;
						$this->_redirect('transaction/expense/edit/id/'.$this->_getParam('id'));
					} else {
						$sessSuccess = new Zend_Session_Namespace('update_payment_success');
						$sessSuccess->status = 2;
						$this->_redirect('transaction/expense/edit/id/'.$this->_getParam('id'));
					}
				} else {
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));


				/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
				$fileInfo 	=  $adapter->getFileInfo('file'); 
				if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
					$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
					        ->addValidator('Size',false,array('max'=>2024000),'file')
							->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
					$adapter->setDestination("..".$this->view->filepath,'file');
					$fileInfo 	         	  =   $adapter->getFileInfo('file');
					$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
					$postArray['extension']   =   $fileArray['1'];
					$renameFile 		  	  =   trim($id."_".rand(10,10000)."_".$id.".".$fileArray['1']);
					$postArray['receipt_id']  =   $renameFile;
					$adapter->addFilter('Rename',"..".$this->view->filepath.$renameFile);
						if ($adapter->isValid('file') && $adapter->receive('file')) {
							//unlink($this->view->fileuploadpath.$postArray['attachment']);
							$postArray['receipt_id'] =   $renameFile;
						} else {
							$postArray['receipt_id'] =  $postArray['attachment'];
						}
				} else {
					$postArray['receipt_id'] =  $postArray['attachment'];
				}*/
				$payment_account = explode("_", $postArray['payment_account']);
				$postArray['pay_account'] = $payment_account[0];

				if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
					$expenseTransaction = $this->transaction->updateExpenseTransaction($postArray,$id,2);
				} else if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
					$postArray['approval_for'] = $logSession->id;
					$expenseTransaction = $this->transaction->updateExpenseTransaction($postArray,$id,1);
				}
				if($expenseTransaction) {
					$sessSuccess = new Zend_Session_Namespace('update_success_expense');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/expense/edit/id/'.$this->_getParam('id'));
				} else {
						$this->view->error = 'Expense Transaction cannot be updated. Kindly try again later';
				}
			}
				
			}

			$delid = base64_decode($this->_getParam('delid'));
			if(isset($delid) && !empty($delid)) {
				$deleteStatus = $this->transaction->deletePayment($delid);
				if($deleteStatus) {
					$sessSuccess = new Zend_Session_Namespace('delete_success_expense_payment');
					$sessSuccess->status = 1;
				}
					$this->_redirect('transaction/expense/edit/id/'.$this->_getParam('id'));
			}
			//echo '<pre>'; print_r($this->view->expense); echo '</pre>'; 
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray','payMethod'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->payMethod      =  $getAccountArray['payMethod'];
			$this->view->receipts 		=  $this->business->getReceipts('',2);
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax();
		}
	}

	public function copyAction() {
		if(!Zend_Session::namespaceIsset('sess_login')) {
			 $this->_redirect('index');
		} else {
			$logSession = new Zend_Session_Namespace('sess_login');
			if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
				$cid = $logSession->proxy_cid;
			} else {
				$cid = $logSession->cid;
			}
			$this->view->filepath    =  $this->uploadPath.$cid."/receipts/";
			$this->view->nextId 	 =  $this->transaction->getNextExpenseTransaction();
			$id = base64_decode($this->_getParam('id'));
			if(!isset($id) || $id=='') {
				$this->_redirect('transaction/expense');
			} else {
				$this->view->expense  =  $this->transaction->getExpenseTransaction($id);
				if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
				} else {
					$this->view->expenseList  =  $this->transaction->getExpenseTransactionList($id);
					if(!$this->view->expense) {
					$this->_redirect('transaction/expense');
					} 
				}
			}
			if($this->_request->isPost()) {
				$postArray  		   = $this->getRequest()->getPost();
				$postArray['date']	   = date("Y-m-d",strtotime(trim($postArray['date'])));
				$postArray['due_date'] = date("Y-m-d",strtotime(trim($postArray['due_date'])));


				/*$adapter    =  new Zend_File_Transfer_Adapter_Http();
				$fileInfo 	=  $adapter->getFileInfo('file'); 
				if(isset($fileInfo['file']['name']) && ($fileInfo['file']['name'] != '')) {
					$adapter->addValidator('Count', false, array('min' =>1, 'max' => 2))
					        ->addValidator('Size',false,array('max'=>2024000),'file')
							->addValidator('Extension',false,'pdf,jpg,doc,docx,png','file');
					$adapter->setDestination("..".$this->view->filepath,'file');
					$fileInfo 	         	  =   $adapter->getFileInfo('file');
					$fileArray		  		  =   explode('.',$fileInfo['file']['name']);
					$postArray['extension']   =   $fileArray['1'];
					$renameFile 		  	  =   trim($this->view->nextId."_".rand(10,10000)."_".$this->view->nextId.".".$fileArray['1']);
					$postArray['receipt_id']  =   $renameFile;
					$adapter->addFilter('Rename',"..".$this->view->filepath.$renameFile);
						if ($adapter->isValid('file') && $adapter->receive('file')) {
							$postArray['receipt_id'] =   $renameFile;
						} else {
							$postArray['receipt_id'] =  $postArray['attachment'];
						}
				} else {
					$postArray['receipt_id'] =  $postArray['attachment'];
				}*/
				$payment_account = explode("_", $postArray['payment_account']);
				$postArray['pay_account'] = $payment_account[0];
				if(isset($postArray['approve_expense']) && !empty($postArray['approve_expense'])) {
						$postArray['approval_for'] = $logSession->id;
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,1);
					} else if(isset($postArray['unapprove_save']) && !empty($postArray['unapprove_save'])) {
						$expenseTransaction = $this->transaction->insertExpenseTransaction($postArray,$cid,2);
					}
				if($expenseTransaction) {
					$sessSuccess = new Zend_Session_Namespace('insert_success_expense');
					$sessSuccess->status = 1;
					$this->_redirect('transaction/expense');
				} else {
						$this->view->error = 'Expense Transaction cannot be added. Kindly try again later';
				}
				
			}
			//echo '<pre>'; print_r($this->view->expense); echo '</pre>'; 
			$getAccountArray            =  $this->accountData->getData(array('currencies','creditTermArray'));
			$this->view->currencies     =  $getAccountArray['currencies'];
			$this->view->creditTerm     =  $getAccountArray['creditTermArray'];
			$this->view->receipts 		=  $this->business->getReceipts('',2);
			$this->view->payAccount		=  $this->transaction->getPaymentAccount();
			$this->view->approveUser	=  $this->settings->getApproveUsers($cid);
			$this->view->vendor 		=  $this->transaction->getVendorDetails();
			$this->view->expenseAccount	=  $this->transaction->getExpenseAccount();
			$this->view->taxCode    	=  $this->transaction->getTax();
		}
	}

	public function ajaxUploadAction() {

		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
			$cid = $logSession->proxy_cid;
		} else {
			$cid = $logSession->cid;
		}
		$this->view->filepath    =  "..".$this->uploadPath.$cid."/receipts/";
		$action = $this->_getParam('operation');

		if($action=='add') {
				$this->view->nextId 	 =  $this->transaction->getNextExpenseTransaction();

				$uploader = new FileUpload('uploadfile');   
				$uploader->allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'doc');
				$uploader->sizeLimit = 10485760;
				$extension = $uploader->getExtension();
				$newfilename  = $this->view->nextId."_".rand(10,10000)."_expense.".$extension;
				$uploader->newFileName = $newfilename;
				$result = $uploader->handleUpload($this->view->filepath);

				if (!$result) {

				  echo json_encode(array(

				          'status' => "failure",

				          'file' => $uploader->getErrorMsg()

				       ));    

				} else {

				    echo json_encode(array ( 'data' => array(

				            'status' => "success",

				            'file' => $uploader->getFileName()

				         )));

				}
		}  else if($action=='edit') {

				$fileid = $this->_getParam('id');
				$uploader = new FileUpload('uploadfile');   
				$uploader->allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'doc');
				$uploader->sizeLimit = 10485760;
				$extension = $uploader->getExtension();
				$newfilename  = $fileid."_".rand(10,10000)."_expense.".$extension;
				$uploader->newFileName = $newfilename;
				$result = $uploader->handleUpload($this->view->filepath);

				if (!$result) {

				  echo json_encode(array(

				          'status' => "failure",

				          'file' => $uploader->getErrorMsg()

				       ));    

				} else {

				    echo json_encode(array ( 'data' => array(

				            'status' => "success",

				            'file' => $uploader->getFileName()

				         )));

				}
		} 
	}

	public function ajaxRemoveAction() {

		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
			$cid = $logSession->proxy_cid;
		} else {
			$cid = $logSession->cid;
		}
		$this->view->filepath    =  "..".$this->uploadPath.$cid."/receipts/";
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='fileRemove') {
					$unlinkFile = unlink($this->view->filepath.$ajaxVal['id']);
					if($unlinkFile) {
						echo "success";
					} else {
						echo "failure";
					}
				}
			}
		}

	}

	public function ajaxRefreshAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
			$cid = $logSession->proxy_cid;
		} else {
			$cid = $logSession->cid;
		}
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='vendorRefresh') {
					$this->vendor 		=  $this->transaction->getVendorDetails();
					if($this->vendor) {
							echo '<select class="select2 form-control" name="vendor" id="vendor"  onchange="return getReceipt(this.value);">';
							echo '<option value="">Select</option>';
						foreach ($this->vendor as $vendor) {
							if($ajaxVal['id']==$vendor['id'])
                                $vendorSelect = 'selected';
                            else
                                $vendorSelect = '';
							echo '<option value='.$vendor['id'].' '.$vendorSelect.'>'.$vendor['vendor_name'].'</option>';
						}
						echo '</select>';
					}
				} else if($ajaxVal['action']=='payaccountRefresh') {
					$this->payAccount		=  $this->transaction->getPaymentAccount();
					if($this->payAccount) {
							echo '<select class="form-control" name="payment_account" id="payment_account" onchange="triggerPayment();">';
							echo '<option value="">Select</option>';
						foreach ($this->payAccount as $pay) {
							$pays = $pay['id']."_".$pay['account_id']."_".$pay['account_type'];
							if($ajaxVal['id']==$pays)
                                $paySelect = 'selected';
                            else
                                $paySelect = '';
                           //echo '<option value='.$pay['id'].' '.$paySelect.'>'.$pay['account_name'].'</option>';
							echo '<option value='.$pay['id']."_".$pay['account_id']."_".$pay['account_type'].' '.$paySelect.'>'.$pay['account_name'].'</option>';
						}
						echo '</select>';
					}
				} else if($ajaxVal['action']=='expenseRefresh') {
					$this->expenseAccount	=  $this->transaction->getExpenseAccount();
					if($this->expenseAccount) {
						$jsonEncode = json_encode($this->expenseAccount);
						echo $jsonEncode;
						/*echo '<select class="form-control" name="expense_type_'.$ajaxVal['expense'].'" id="expense_type_'.$ajaxVal['expense'].'" required>';
						echo '<option value="">Select</option>';
						foreach ($this->expenseAccount as $expense) {
							if($ajaxVal['id']==$expense['id'])
                                $expenseSelect = 'selected';
                            else
                                $expenseSelect = '';
							echo '<option value='.$expense['id'].' '.$expenseSelect.'>'.$expense['account_name'].'</option>';
						}
						echo '</select>';*/
					}
				}
			}
		}
	}

	public function ajaxCallAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$logSession = new Zend_Session_Namespace('sess_login');
		if(isset($logSession->proxy_cid) && !empty($logSession->proxy_cid)) {
			$cid = $logSession->proxy_cid;
		} else {
			$cid = $logSession->cid;
		}
		if($this->_request->isXmlHttpRequest()) {
			if ($this->_request->isPost()) {
				$ajaxVal = $this->getRequest()->getPost();
				if($ajaxVal['action']=='save_draft_expense') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));
					$ajaxVal['due_date'] = date("Y-m-d",strtotime(trim($ajaxVal['due_date'])));
					if(isset($ajaxVal['vendor']) && !empty($ajaxVal['vendor'])) {
						$ajaxVal['vendor'] = trim($ajaxVal['vendor']);
					} else {
						$ajaxVal['vendor'] = NULL;
					}
					if(isset($ajaxVal['pay_account']) && !empty($ajaxVal['pay_account'])) {
						$ajaxVal['pay_account'] = trim($ajaxVal['pay_account']);
					} else {
						$ajaxVal['pay_account'] = NULL;
					}
					if(isset($ajaxVal['receipt_id']) && !empty($ajaxVal['receipt_id'])) {
						$ajaxVal['receipt_id'] = trim($ajaxVal['receipt_id']);
					} else {
						$ajaxVal['receipt_id'] = NULL;
					}
					$expenseTransaction = $this->transaction->insertExpenseTransaction($ajaxVal,$cid,3);
					if($expenseTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_expense_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} else if($ajaxVal['action']=='update_draft_expense') {
					$ajaxVal['date'] 	 = date("Y-m-d",strtotime(trim($ajaxVal['date'])));
					$ajaxVal['due_date'] = date("Y-m-d",strtotime(trim($ajaxVal['due_date'])));
					if(isset($ajaxVal['vendor']) && !empty($ajaxVal['vendor'])) {
						$ajaxVal['vendor'] = trim($ajaxVal['vendor']);
					} else {
						$ajaxVal['vendor'] = NULL;
					}
					if(isset($ajaxVal['pay_account']) && !empty($ajaxVal['pay_account'])) {
						$ajaxVal['pay_account'] = trim($ajaxVal['pay_account']);
					} else {
						$ajaxVal['pay_account'] = NULL;
					}
					if(isset($ajaxVal['receipt_id']) && !empty($ajaxVal['receipt_id'])) {
						$ajaxVal['receipt_id'] = trim($ajaxVal['receipt_id']);
					} else {
						$ajaxVal['receipt_id'] = NULL;
					}
					$expenseTransaction = $this->transaction->updateExpenseTransaction($ajaxVal,$ajaxVal['expense_id'],3);
					if($expenseTransaction) {
						$sessDraft = new Zend_Session_Namespace('sess_draft_expense_insert');
						$sessDraft->status = 1;
						echo "success";
					} else {
						echo "Failure";
					}
				} 
			}
		} 
	}


		
}

?>